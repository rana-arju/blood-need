import { randomBytes } from "crypto";

console.log(randomBytes(32).toString("base64"));
