// Service Worker Registration Script
(() => {
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", async () => {
      try {
        // Unregister any existing service workers first to avoid conflicts
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.unregister();
        }

        console.log("Registering service worker...");
        const registration = await navigator.serviceWorker.register(
          "/service-worker.js",
          {
            scope: "/",
            updateViaCache: "none",
          }
        );

        console.log("Service worker registered successfully:", registration);

        // Store the registration globally
        window.swRegistration = registration;

        // Dispatch event for other components to know service worker is registered
        window.dispatchEvent(
          new CustomEvent("swRegistered", { detail: registration })
        );

        // Wait for the service worker to be activated
        if (registration.installing) {
          registration.installing.addEventListener("statechange", (event) => {
            if (event.target.state === "activated") {
              console.log("Service worker activated");
              window.dispatchEvent(
                new CustomEvent("swActivated", { detail: registration })
              );
            }
          });
        } else if (registration.active) {
          console.log("Service worker already active");
          window.dispatchEvent(
            new CustomEvent("swActivated", { detail: registration })
          );
        }
      } catch (error) {
        console.error("Service worker registration failed:", error);
      }
    });

    // Listen for messages from the service worker
    navigator.serviceWorker.addEventListener("message", (event) => {
      if (event.data && event.data.type === "SW_ACTIVATED") {
        console.log("Service worker is now active and controlling the page");
        window.dispatchEvent(
          new CustomEvent("swActivated", {
            detail: navigator.serviceWorker.controller,
          })
        );
      }
    });
  } else {
    console.log("Service workers are not supported");
  }
})();
