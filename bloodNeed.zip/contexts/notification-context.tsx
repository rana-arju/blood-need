"use client";

import type React from "react";
import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
} from "react";
import { initializeApp, getApps } from "firebase/app";
import {
  getMessaging,
  getToken,
  onMessage,
  isSupported,
} from "firebase/messaging";

import {
  getVapidKey,
  notificationService,
  registerFCMToken,
} from "@/services/notification";
import { toast } from "sonner";
import { useSession } from "next-auth/react";
import { registerServiceWorker } from "@/utils/register-service-worker";

export interface Notification {
  id: string;
  title: string;
  body: string;
  url?: string;
  isRead: boolean;
  createdAt: string;
  userId: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  loading: boolean;
  permissionGranted: boolean | null;
  requestPermission: () => Promise<boolean>;
  loadNotifications: (page: number, limit: number) => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  removeNotification: (id: string) => Promise<void>;
  notificationsEnabled: boolean | null;
  isLoading: boolean;
  enableNotifications: () => Promise<{ success: boolean; error?: any }>;
  disableNotifications: () => Promise<{ success: boolean; error?: any }>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(
  undefined
);

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY!,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN!,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID!,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET!,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID!,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID!,
};

export function NotificationProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState<boolean | null>(
    null
  );
  const [notificationsEnabled, setNotificationsEnabled] = useState<
    boolean | null
  >(null);
  const [swRegistration, setSwRegistration] =
    useState<ServiceWorkerRegistration | null>(null);
  const { data: session } = useSession();
  const userId = session?.user?.id;

  const registeringPromiseRef = useRef<Promise<any> | null>(null);
  const firebaseInitializedRef = useRef(false);

  useEffect(() => {
    if (
      !firebaseInitializedRef.current &&
      typeof window !== "undefined" &&
      !getApps().length
    ) {
      try {
        initializeApp(firebaseConfig);
        firebaseInitializedRef.current = true;
        console.log("Firebase initialized");
      } catch (error) {
        console.error("Firebase init failed:", error);
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const checkPermission = async () => {
      const permission = Notification.permission;
      const isGranted = permission === "granted";
      setPermissionGranted(isGranted);
      const stored = localStorage.getItem("notificationsEnabled");
      const isEnabled = isGranted && stored === "true";
      setNotificationsEnabled(isEnabled);

      if (isEnabled && userId) {
        await registerForPushNotifications();
      }
    };

    checkPermission();
  }, [userId]);

  const registerForPushNotifications = useCallback(async () => {
    if (!userId) return { success: false, error: "User not logged in" };
    if (registeringPromiseRef.current) return registeringPromiseRef.current;

    const register = async () => {
      try {
        if (!(await isSupported())) {
          return { success: false, error: "FCM not supported" };
        }

        const registration = await registerServiceWorker();
        if (!registration) throw new Error("SW registration failed");
        setSwRegistration(registration);

        // Ensure service worker is active
        if (registration.installing) {
          await new Promise<void>((resolve) => {
            registration.installing?.addEventListener("statechange", (e) => {
              if ((e.target as ServiceWorker).state === "activated") resolve();
            });
          });
        }

        if (registration.active) {
          registration.active.postMessage({
            type: "FIREBASE_CONFIG",
            config: firebaseConfig,
          });
        }

        let vapidKey = await getVapidKey().catch(
          () => process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY
        );
        if (!vapidKey) throw new Error("No VAPID key");

        const messaging = getMessaging();
        let token: string | null = null;
        for (let i = 0; i < 3 && !token; i++) {
          try {
            token = await getToken(messaging, {
              vapidKey,
              serviceWorkerRegistration: registration,
            });
          } catch {
            await new Promise((r) => setTimeout(r, 1000));
          }
        }

        if (!token) throw new Error("FCM token fetch failed");
        await registerFCMToken(token, userId);
        setNotificationsEnabled(true);
        localStorage.setItem("notificationsEnabled", "true");

        onMessage(messaging, (payload) => {
          console.log("Foreground FCM message:", payload);
          if (payload.notification) {
            const newNotification: Notification = {
              id: payload.messageId || `temp-${Date.now()}`,
              title: payload.notification.title || "New Notification",
              body: payload.notification.body || "",
              url: payload.data?.url,
              isRead: false,
              createdAt: new Date().toISOString(),
              userId,
            };
            setNotifications((prev) => [newNotification, ...prev]);
            setUnreadCount((prev) => prev + 1);

            toast.success(newNotification.title, {
              description: newNotification.body,
              action: newNotification.url ? (
                <a
                  href={newNotification.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary text-white px-3 py-2 rounded-md text-xs"
                >
                  View
                </a>
              ) : undefined,
            });
          }
        });

        return { success: true };
      } catch (error) {
        console.error("Push registration failed:", error);
        return { success: false, error };
      }
    };

    registeringPromiseRef.current = register().finally(() => {
      registeringPromiseRef.current = null;
    });

    return registeringPromiseRef.current;
  }, [userId]);

  const requestPermission = async (): Promise<boolean> => {
    if (!userId || typeof window === "undefined") return false;

    try {
      setIsLoading(true);
      const permission = await Notification.requestPermission();
      const granted = permission === "granted";
      setPermissionGranted(granted);

      if (granted) {
        const result = await registerForPushNotifications();
        if (result.success) {
          setNotificationsEnabled(true);
          localStorage.setItem("notificationsEnabled", "true");
        }
      }

      setIsLoading(false);
      return granted;
    } catch (error) {
      console.error("Permission request error:", error);
      setIsLoading(false);
      return false;
    }
  };

  const enableNotifications = () =>
    requestPermission().then((granted) => ({
      success: granted,
      error: granted ? undefined : "Permission denied",
    }));

  const disableNotifications = async () => {
    if (!userId) return { success: false, error: "No user" };

    setIsLoading(true);
    try {
      setNotificationsEnabled(false);
      localStorage.setItem("notificationsEnabled", "false");

      if (swRegistration) {
        const subscription = await swRegistration.pushManager.getSubscription();
        if (subscription) await subscription.unsubscribe();
      }

      await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/notifications/unsubscribe`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${userId}`,
          },
        }
      );

      setIsLoading(false);
      return { success: true };
    } catch (error) {
      console.error("Disable notification error:", error);
      setIsLoading(false);
      return { success: false, error };
    }
  };

  const loadNotifications = useCallback(
    async (page: number, limit: number) => {
      if (!userId) return;
      try {
        setLoading(true);
        const response = await notificationService.getNotifications(
          page,
          limit,
          userId
        );
        setNotifications((prev) =>
          page === 1
            ? response.notifications
            : [...prev, ...response.notifications]
        );
        setUnreadCount(response.unreadCount);
      } catch (error) {
        toast.error("Failed to load notifications.");
      } finally {
        setLoading(false);
      }
    },
    [userId]
  );

  const markAsRead = useCallback(
    async (id: string) => {
      if (!userId) return;
      try {
        await notificationService.markAsRead(id, userId);
        setNotifications((prev) =>
          prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
        );
        setUnreadCount((prev) => Math.max(0, prev - 1));
      } catch (error) {
        toast.error("Error marking as read.");
      }
    },
    [userId]
  );

  const markAllAsRead = useCallback(async () => {
    if (!userId) return;
    try {
      await notificationService.markAllAsRead(userId);
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (error) {
      toast.error("Error marking all as read.");
    }
  }, [userId]);

  const removeNotification = useCallback(
    async (id: string) => {
      if (!userId) return;
      try {
        await notificationService.removeNotification(id, userId);
        const toRemove = notifications.find((n) => n.id === id);
        setNotifications((prev) => prev.filter((n) => n.id !== id));
        if (toRemove && !toRemove.isRead) {
          setUnreadCount((prev) => Math.max(0, prev - 1));
        }
      } catch (error) {
        toast.error("Error removing notification.");
      }
    },
    [notifications, userId]
  );

  const contextValue: NotificationContextType = {
    notifications,
    unreadCount,
    loading,
    permissionGranted,
    requestPermission,
    loadNotifications,
    markAsRead,
    markAllAsRead,
    removeNotification,
    notificationsEnabled,
    isLoading,
    enableNotifications,
    disableNotifications,
  };

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context)
    throw new Error(
      "useNotifications must be used within NotificationProvider"
    );
  return context;
}
