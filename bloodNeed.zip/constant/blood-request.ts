export const bloodTypes = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export const requestStatuses = ["pending", "fulfilled", "cancelled"];
