"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { toast } from "sonner";

// Helper to convert VAPID key
function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Wait for service worker to be active
async function waitForActiveServiceWorker(): Promise<ServiceWorkerRegistration> {
  const registration = await navigator.serviceWorker.ready;
  if (registration.active) return registration;

  return new Promise((resolve) => {
    const interval = setInterval(() => {
      if (registration.active) {
        clearInterval(interval);
        resolve(registration);
      }
    }, 100);
  });
}

export function useNotificationSubscription() {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { data: session } = useSession();

  useEffect(() => {
    if (!session?.user?.id) return;

    const checkSubscription = async () => {
      if ("serviceWorker" in navigator && "PushManager" in window) {
        const registration = await waitForActiveServiceWorker();
        const subscription = await registration.pushManager.getSubscription();
        setIsSubscribed(!!subscription);
      }
    };

    checkSubscription();
  }, [session]);

  const subscribe = async () => {
    if (!session?.user?.id) return;

    try {
      const registration = await waitForActiveServiceWorker();

      const existingSubscription =
        await registration.pushManager.getSubscription();
      if (existingSubscription) {
        console.log("Already subscribed:", existingSubscription);
        setIsSubscribed(true);
        return;
      }

      const newSubscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(
          process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!
        ),
      });

      console.log("newSubscription", newSubscription);

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/notifications/web-push/subscribe`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session?.user?.id}`,
          },
          body: JSON.stringify({ subscription: newSubscription }),
        }
      );

      if (response.ok) {
        console.log("Subscription saved on the server.");
        toast.success("Notification enabled successfully");
        setIsSubscribed(true);
        return true;
      } else {
        console.error("Failed to save subscription on the server.");
        return false;
      }
    } catch (error) {
      console.error("Error during subscription:", error);
      return false;
    }
  };

  const unsubscribe = async () => {
    if (!session?.user?.id) return;

    try {
      const registration = await waitForActiveServiceWorker();
      const subscription = await registration.pushManager.getSubscription();

      if (subscription) {
        await subscription.unsubscribe();
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/notifications/unsubscribe`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${session.user.id}`,
            },
          }
        );

        if (response.ok) {
          console.log("Unsubscribed from push notifications");
          setIsSubscribed(false);
        } else {
          console.error("Failed to unsubscribe on the server");
        }
      }
    } catch (error) {
      console.error("Error unsubscribing from push notifications:", error);
    }
  };

  return { isSubscribed, subscribe, unsubscribe };
}
