/**
 * Register the service worker for the application
 * @returns A promise that resolves to the service worker registration
 */

// Extend the Window interface to include swRegistration
declare global {
  interface Window {
    swRegistration?: ServiceWorkerRegistration;
  }
}
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!("serviceWorker" in navigator)) {
    console.warn("Service workers are not supported in this browser");
    return null;
  }

  try {
    // Check if we already have a registration
    if (window.swRegistration) {
      return window.swRegistration;
    }

    // Wait for the registration event
    const registration = await new Promise<ServiceWorkerRegistration>(
      (resolve) => {
        if (window.swRegistration) {
          resolve(window.swRegistration);
        } else {
          window.addEventListener("swRegistered", (e: any) => {
            resolve(e.detail);
          });
        }
      }
    );

    return registration;
  } catch (error) {
    console.error("Error registering service worker:", error);
    return null;
  }
}
