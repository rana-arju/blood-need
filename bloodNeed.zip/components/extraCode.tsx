//if keep a sheet / sidebar on mobile device then add this on header

/*

<Sheet>
  <SheetTrigger asChild>
    <Button variant="outline" size="icon">
      <Menu className="h-[1.2rem] w-[1.2rem]" />
      <span className="sr-only">Toggle menu</span>
    </Button>
  </SheetTrigger>
  <SheetContent>
    <SheetHeader>
      <SheetTitle>Menu</SheetTitle>
      <SheetDescription>
        Navigate through our blood donation community
      </SheetDescription>
    </SheetHeader>
    <nav className="mt-6">
      <ul className="space-y-4">
        <NavItems />
      </ul>
    </nav>
  </SheetContent>
</Sheet>;
*/