import SignUpForm from "@/components/SignUpForm"

export default function SignUpPage() {
  return (
    <div className="w-full min-h-screen">
      <SignUpForm />
    </div>
  )
}

