import SignInForm from "@/components/SignInForm"

export default function SignInPage() {
  return (
    <div className="w-full min-h-screen">
      <SignInForm />
    </div>
  )
}

