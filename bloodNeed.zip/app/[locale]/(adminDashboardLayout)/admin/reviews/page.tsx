import { ReviewsList } from "@/components/admin/ReviewsList";

export default function ReviewsPage() {
  return (
    <div className="container px-0 py-8 mx-auto">
      <ReviewsList />
    </div>
  );
}
