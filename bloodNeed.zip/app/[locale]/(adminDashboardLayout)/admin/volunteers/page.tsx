import { VolunteersList } from "@/components/admin/VolunteersList";

export default function VolunteersPage() {
  return <VolunteersList />;
}
