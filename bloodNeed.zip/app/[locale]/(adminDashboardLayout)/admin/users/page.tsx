import { UsersList } from "@/components/admin/UsersList";

export default function UsersPage() {
 return (
   <div className=" mx-auto py-8">
     <UsersList />
   </div>
 );
}
