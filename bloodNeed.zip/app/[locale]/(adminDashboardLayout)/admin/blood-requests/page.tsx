import { BloodRequestsList } from "@/components/admin/BloodRequestsList";

export default function BloodRequestsPage() {
  return <BloodRequestsList />;
}
