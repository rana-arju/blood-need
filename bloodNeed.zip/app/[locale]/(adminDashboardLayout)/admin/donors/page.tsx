import { DonorsList } from "@/components/admin/DonorsList";

export default function DonorsPage() {
  return (
    <div className="container px-0 mx-auto py-10">
      <DonorsList />
    </div>
  );
}
