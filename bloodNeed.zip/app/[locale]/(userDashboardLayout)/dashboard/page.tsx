import { UserDashboardOverview } from "@/components/user/UserDashboardOverview";

export default function UserDashboardPage() {
  return <UserDashboardOverview />;
}
