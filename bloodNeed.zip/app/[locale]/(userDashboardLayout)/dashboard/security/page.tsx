import { SecuritySettings } from "@/components/user/SecuritySettings";

export default function SecurityPage() {
  return <div className="h-screen">

    <SecuritySettings />
  </div>
  
}
