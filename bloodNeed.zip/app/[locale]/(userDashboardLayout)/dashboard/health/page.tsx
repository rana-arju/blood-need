import { UserHealthHistory } from "@/components/user/UserHealthHistory";

export default function HealthPage() {
  return <UserHealthHistory />;
}
