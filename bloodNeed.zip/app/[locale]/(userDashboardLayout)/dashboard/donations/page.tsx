import { UserDonationHistory } from "@/components/user/UserDonationHistory";


export default function DonationsPage() {
  return <UserDonationHistory />;
}
