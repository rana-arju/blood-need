import { ProfileDetails } from "@/components/user/ProfileDetails";

export default function ProfilePage() {
  return <ProfileDetails />;
}
