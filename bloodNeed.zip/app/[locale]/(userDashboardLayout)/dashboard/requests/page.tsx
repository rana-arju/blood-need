import { UserBloodRequestsList } from "@/components/user/UserBloodRequests";

export default function RequestsPage() {
  return <UserBloodRequestsList />;
}
