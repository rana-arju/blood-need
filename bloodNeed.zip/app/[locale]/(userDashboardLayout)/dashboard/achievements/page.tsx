import { UserAchievements } from "@/components/user/UserAchievements";

export default function AchievementsPage() {
  return <UserAchievements />;
}
