"use client";

import { useEffect, useState } from "react";
import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { useSession } from "next-auth/react";

// Define the window interface to include our custom properties
declare global {
  interface Window {
    swRegistration?: ServiceWorkerRegistration;
    swActivated?: boolean;
  }
}

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

export default function FirebaseInit() {
  const { data: session, status } = useSession();
  const [serviceWorkerReady, setServiceWorkerReady] = useState(false);

  // Listen for service worker activation
  useEffect(() => {
    const handleSwActivated = () => {
      console.log("Service worker activated event received");
      setServiceWorkerReady(true);
    };

    window.addEventListener("swActivated", handleSwActivated);

    // Check if service worker is already active
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      console.log("Service worker is already controlling the page");
      setServiceWorkerReady(true);
    }

    return () => {
      window.removeEventListener("swActivated", handleSwActivated);
    };
  }, []);

  // Initialize Firebase only when service worker is ready and user is logged in
  useEffect(() => {
    // Only proceed if the user is logged in
    if (status !== "authenticated" || !session?.user?.id) {
      console.log("User not authenticated, skipping Firebase initialization");
      return;
    }

    // Only proceed if the service worker is ready
    if (!serviceWorkerReady) {
      console.log("Service worker not ready yet, waiting...");
      return;
    }

    const initialize = async () => {
      try {
        console.log("Initializing Firebase for authenticated user");

        // Initialize Firebase
        const app = initializeApp(firebaseConfig);

        // Check if browser supports service workers and push notifications
        if ("serviceWorker" in navigator && "PushManager" in window) {
          try {
            // Replace navigator.serviceWorker.ready with this:
            async function waitForActiveServiceWorker(): Promise<ServiceWorkerRegistration> {
              const registration = await navigator.serviceWorker.ready;
              if (registration.active) return registration;

              return new Promise((resolve) => {
                const interval = setInterval(() => {
                  if (registration.active) {
                    clearInterval(interval);
                    resolve(registration);
                  }
                }, 100);
              });
            }

            // Get the service worker registration
            const swRegistration = await waitForActiveServiceWorker();
            console.log("Service worker is ready:", swRegistration);

            // Pass Firebase config to service worker
            if (swRegistration.active) {
              swRegistration.active.postMessage({
                type: "FIREBASE_CONFIG",
                config: {
                  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
                  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
                  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
                  storageBucket:
                    process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
                  messagingSenderId:
                    process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
                  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
                },
              });
            }

            // Initialize Firebase Messaging
            const messaging = getMessaging(app);

            // Request permission and get token
            const permission = await Notification.requestPermission();

            if (permission === "granted") {
              try {
                // Get FCM token
                const currentToken = await getToken(messaging, {
                  vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY,
                  serviceWorkerRegistration: swRegistration,
                });

                if (currentToken) {
                  console.log("FCM token:", currentToken);

                  // Send the token to your server
                  try {
                    // Check if the API endpoint exists
                    const apiUrl = "/api/notifications/register-device";

                    const response = await fetch(apiUrl, {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                      },
                      body: JSON.stringify({ token: currentToken }),
                    });

                    if (response.ok) {
                      console.log("FCM token registered with server");
                    } else {
                      console.error(
                        "Failed to register FCM token with server:",
                        response.status
                      );
                    }
                  } catch (error) {
                    console.error(
                      "Error registering FCM token with server:",
                      error
                    );
                  }
                } else {
                  console.log("No registration token available");
                }

                // Handle foreground messages
                onMessage(messaging, (payload) => {
                  console.log("Foreground message received:", payload);
                  // Display notification using the Notification API
                  if (payload.notification) {
                    const { title, body } = payload.notification;
                    new Notification(title!, {
                      body,
                      icon: "/icons/icon-192x192.png",
                    });
                  }
                });
              } catch (error) {
                console.error("Error getting FCM token:", error);
              }
            }
          } catch (error) {
            console.error("Error setting up push notifications:", error);
          }
        } else {
          console.log("Browser does not support push notifications");
        }
      } catch (error) {
        console.error("Error initializing Firebase:", error);
      }
    };

    initialize();
  }, [session, status, serviceWorkerReady]);

  return null;
}
