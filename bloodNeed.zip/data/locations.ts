export const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
import district from "./districts.json"
import division from "./divisions.json"
import upazila from "./upazilas.json"
export const divisions = division;

export const districts = district

export const upazilas = upazila